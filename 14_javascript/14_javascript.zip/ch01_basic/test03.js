/*
 * NodeJs 환경이 설치되어있어야 콘솔창 실행이 가능함
 * 
 * cmd 명령어 node -v : 설치된 버전을 확인
 * npm -v : maven과 유사하게 생각하자
 * 
 * node 파일명
 * node test03.js or node test03
 * 
 * javascript 에서 명령문 뒤에 ;를 줘도 되고 안줘도 되지만 통일성을 위해 주자
 */
// /**/ : 주석문

console.log("Hello~");