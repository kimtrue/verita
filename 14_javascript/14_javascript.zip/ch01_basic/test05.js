/** 
 * 자바스크립트 변수
 * - 변수를 엄격하게 사용...
 * - "use strict" 가장 위쪽에 선언 : ECMA5(ES5)부터 사용가능
*/

"use strict"

name = "홍길동";
age = 30;

console.log(name, age);

//변수 선언시 var 키워드 사용 가능
var id = "hong";
console.log(id);
