/**
 * 자바 스크립트 연산자
 * 같다 , 다르다의 비교 
 * ==,   !=  : 사용X
 * ===,  !== : 일치 연산자. 값과 타입이 같은지 비교한다
 * 
 */

let i = 100;
let j = "100";

console.log("i == j : ", i == j); // true
console.log("i === j : ", i === j); //false 