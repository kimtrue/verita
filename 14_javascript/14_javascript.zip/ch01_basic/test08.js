//호이스팅 이해 퀴즈
console.log(id);

var id = "테스트";
console.log(id);

/**
 * 1단계
 * var id;
 * 
 * 2단계
 * consol.log(id); =>undefined 
 * id="테스트"
 * consol.log(id);
 * 
 */