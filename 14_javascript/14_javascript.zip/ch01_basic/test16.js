/**
 * 문자열
 *  - 여러 줄 입력 방식
 * 
 */

 let msg = "저의" + 
 "이름은" + 
 "고길동 입니다.";
console.log(msg);


//javascript
// \아직 문자열이 끝나지 않았다
msg = "저의\
이름은\
고길동 입니다.";
console.log(msg);

//백틱
//입력된 그대로 출력
msg = `저의
이름은
고길동 입니다.`;
console.log(msg);


