/**
 * 데이터 타입
 * 
 * 기본데이터 타입
 * string 
 * number
 * boolean
 * undefined
 * null
 * 
 * 객체 데이터 타입
 * -object(날짜)
 * 
 */

var num1 = 10; //number type
console.log("number : ", num1);

var num2 = 10.3; //number type 정수와 실수 따로 구분하지 않고 사용가능
console.log("number : ", num2);

var msg = "hi";
console.log("string : ", msg);

var msg2 = 'hello';
console.log("string : ", msg2);

var bool = true;
console.log("boolean : ", bool);

var nullval = null;
console.log("null : ", nullval);

var unVal;
console.log("unVal", unVal); //undefiend

//객체
var obj = {};
console.log("object : ", obj);