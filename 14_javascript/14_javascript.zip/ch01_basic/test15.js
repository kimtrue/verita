/**
 *  자바스크립트 문자열
 * - 문자열과 숫자의 "+" 연산의 결과는 문자열
 * - 문자열과 숫자의 "+" 이외의 연산의 결과는 숫자가 된다. 
 * 
 * 
 */

 console.log("10"+1); //101 문자열
 console.log("10"+ "1"); //101 문자열
 console.log("10"- 1); //9 숫자
 console.log("10" * 8); //80 숫자
 console.log("a" * 8); //NaN(Not a Number) 
